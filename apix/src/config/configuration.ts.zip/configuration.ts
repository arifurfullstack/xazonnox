import * as process from 'node:process';

export default () => ({
  productionBuild: process.env.PRODUCTION_BUILD === 'true',
  prefix: process.env.PREFIX ?? null,
  hostname: `http://localhost:${process.env.PORT || 3000}`,
  port: parseInt(process.env.PORT, 10) || 3000,
  mongoCluster:
    process.env.PRODUCTION_BUILD === 'true'
      ? `mongodb://${process.env.DB_USERNAME}:${process.env.DB_PASSWORD}@127.0.0.1:${process.env.DB_PORT}/${process.env.DB_NAME}?authSource=${process.env.AUTH_SOURCE}`
      : `mongodb+srv://webfaisalbd:R6fVp4V9hV33kYdZ@cluster0.fcyg3ew.mongodb.net/${process.env.DB_NAME}?retryWrites=true&w=majority`,
  // JWT Token
  userJwtSecret: process.env.JWT_PRIVATE_KEY_USER,
  adminJwtSecret: process.env.JWT_PRIVATE_KEY_ADMIN,
  vendorJwtSecret: process.env.JWT_PRIVATE_KEY_VENDOR,
  affiliateJwtSecret: process.env.JWT_PRIVATE_KEY_AFFILIATE,
  userTokenExpiredTime: '7d',
  adminTokenExpiredDays: '7d',
  vendorTokenExpiredTime: '7d',
  affiliateTokenExpiredTime: '7d',
  adminTokenExpiredTime: '1d',

  // CDN Api
  cdnUrlBase:
    process.env.PRODUCTION_BUILD === 'true'
      ? 'https://api.dailycarebd.com/api'
      : 'http://localhost:4000/api',

  // Build Script
  themeTargetPath: '/home/dailycarebd.com/ui',
  apiBaseUrl:
    process.env.PRODUCTION_BUILD === 'true'
      ? 'https://api.dailycarebd.com'
      : 'http://localhost:3000',

  // Gmail Api
  gmail: 'saleecom.server@gmail.com',
  googleClientId:
    '939426851018-o57ptqkh3dp40vimvtr700fv9242rhni.apps.googleusercontent.com',
  googleClientSecret: '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',
  googleClientRedirectUrl: 'https://developers.google.com/oauthplayground',
  googleRefreshToken:
    '1//04-JNQ4qKO6Z_CgYIARAAGAQSNwF-L9IrGxZJAuUIO49Bk11F8vzAVGQCcvDy5DE2KBSa8GFfdYNYoiPYwQpF8szWYwKJxSbU9Mo',

  vendorSecretKey: process.env.JWT_PRIVATE_KEY_VENDOR_SECRET,
});
